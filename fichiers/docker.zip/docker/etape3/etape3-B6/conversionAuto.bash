#!/usr/bin/bash

#Korentin 100%

docker kill dockImagick
docker kill dockExcl2CSV
docker rm dockImagick

docker run -dit --name "dockImagick" --rm bigpapoo/sae103-imagick

rm listeFichier
rm -dr fileConverted/

mkdir -p fileNotConverted
mkdir -p fileConverted

docker cp ./ dockImagick:/data/
docker exec dockImagick mkdir -p fileConvert

for ext in jpg jpeg png webp pdf
do
    docker exec dockImagick mogrify -strip *.$ext
    docker exec dockImagick identify *.$ext | cut -d' ' -f1,3 >> listeFichier
done

nbFichier=$(wc -l < listeFichier)
docker exec dockImagick mkdir -p fileConverted

for ((count = 1; count <= nbFichier; count++))
do
    nomFic=$(head -n "$count" < listeFichier | tail -n 1 | cut -d' ' -f1)
    nomFicConv=$(head -n "$count" < listeFichier | tail -n 1 | cut -d' ' -f1 | cut -d'.' -f1).webp
    dimFicX=$(head -n "$count" < listeFichier| tail -n 1 | cut -d' ' -f2 | cut -d'x' -f1)
    dimFicY=$(head -n "$count" < listeFichier| tail -n 1 | cut -d' ' -f2 | cut -d'x' -f2)

    mv "$nomFic" fileNotConverted/"$nomFic"

    docker exec dockImagick convert "$nomFic" fileConvert/"$nomFicConv"
    docker exec dockImagick rm "$nomFic"

    #Verification des dimension du fichier
    if [ $dimFicX -lt 320 ] || [ $dimFicY -lt 200 ]; 
    then
        docker exec dockImagick mogrify -resize 320x200 fileConvert/"$nomFicConv"
    elif [ $dimFicX -gt 960 ] || [ $dimFicY -gt 600 ]; 
    then
        docker exec dockImagick mogrify -resize 960x600 fileConvert/"$nomFicConv"
    fi

    poidFic=$(docker exec dockImagick identify fileConvert/"$nomFicCon" | cut -d' ' -f7 | rev | colrm 1 1 | rev)
    poidFic=$(($poidFic))


    while [ $poidFic -gt 150000 ]
    do
        docker exec dockImagick mogrify -quality 80 fileConvert/"$nomFicConv"
        poidFic=$(docker exec dockImagick identify fileConvert/"$nomFicConv" | cut -d' ' -f7 | rev | colrm 1 1 | rev)
        poidFic=$(($poidFic))
    done

    docker exec dockImagick mv fileConvert/"$nomFicConv" fileConverted/"$nomFicConv"
done

docker cp dockImagick:data/fileConverted/ ./

docker kill dockImagick


docker run -dit --name "dockExcl2CSV" --rm bigpapoo/sae103-excel2csv

ls *.xlsx > listeFichier

docker exec dockExcl2CSV mkdir fileConverted

nbFichier=$(wc -l < listeFichier)

for ((count = 1; count <= nbFichier; count++))
do
    nomFic=$(head -n "$count" < listeFichier | tail -n 1)
    nomFicConv=$(head -n "$count" < listeFichier | tail -n 1 | cut -d'.' -f1).csv

    docker cp ./"$nomFic" dockExcl2CSV:/app/
    docker exec dockExcl2CSV ssconvert "$nomFic" fileConverted/"$nomFicConv"
    
    mv "$nomFic" fileNotConverted/"$nomFic"
done

docker cp dockExcl2CSV:app/fileConverted/ ./

docker kill dockExcl2CSV

rm listeFichier

