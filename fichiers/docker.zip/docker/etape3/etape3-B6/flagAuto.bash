#!/bin/bash

#Enzo 45%
#Ji-o 45%
#Korentin 10%

# Liste des codes pays
countries=(
    za al dz de ar am au at az bh
    be bw br bg ca cv cl cn cy co
    kp kr ci hr cu dk dm eg ec eor
    es us et fj fr ge gb gr gd gt
    hk hu in id ir ie il it jm jp
    jo kz ke kg xk lt my ma mx md
    mn no nz ug uz pk pa nl pe ph
    pl pr pt qa do cz ro lc rs sg
    sk si se ch tj tw th tn tr ua
    zm
)

docker run -dit --name "wgetFlag" --rm bigpapoo/sae103-wget

mkdir drapeau_80x60
mkdir drapeau_20x20

# Télécharger chaque drapeau avec 80px de largeur et 60px de hauteur
for country in "${countries[@]}";
do
  docker exec wgetFlag wget -O "${country}.png" "https://flagcdn.com/80x60/${country}.png"
  docker cp wgetFlag:/data/${country}.png ./drapeau_80x60
done

# Télécharger chaque drapeau avec 80px de largeur et 60px de hauteur
for country in "${countries[@]}";
do
  docker exec wgetFlag wget -O "${country}.jpg" "https://flagcdn.com/w20/${country}.jpg"
  docker cp wgetFlag:/data/${country}.jpg ./drapeau_20x20
done
