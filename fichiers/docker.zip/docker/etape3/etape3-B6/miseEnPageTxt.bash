#!/usr/bin/bash

#Ji-o 30%
#Korentin 55%
#Enzo 15% 

rm listeFichier

mkdir -p fileConverted

for ext in txt data
do 
    ls *.$ext >> listeFichier
done

nbFichier=$(wc -l < listeFichier)

for ((count = 1; count <= nbFichier; count++))
do
    nomFic="$(sed -n "${count}p" listeFichier)"
    nomFicTraiter="$(sed -n "${count}p" listeFichier | cut -d'.' -f1)Traiter.txt"
    extFic=$(sed -n "${count}p" listeFichier | cut -d'.' -f2)

    nbLigne=$(wc -l < "$nomFic")
    nbLigne=$(echo $nbLigne+1 | bc)

    rm fileConverted/"$nomFicTraiter"

    for ((countLi = 1; countLi <= nbLigne; countLi++))
    do
        ligneTraiter="$(sed -n "${countLi}p" "$nomFic")"

        if [ "$extFic" = data ];
        then
            repereSection="$(echo "$ligneTraiter" | cut -d'_' -f1)"
            numeroSection="$(echo "$ligneTraiter" | cut -d'_' -f2)"

            if [ "$repereSection" = "SECTION" ];
            then
                nomFicTraiter="$(sed -n "${count}p" listeFichier | cut -d'.' -f1)Traiter_"$numeroSection".txt"
                ((countLi++))
                ligneTraiter="$(sed -n "${countLi}p" "$nomFic")"
                rm fileConverted/"$nomFicTraiter"
            fi

            repereBalise="$(echo "$ligneTraiter" | cut -d'=' -f1)"

            if [ "$repereBalise" = "TITRE" ];
            then
                ligneTraiter="<h1>$(echo "$ligneTraiter" | cut -d'=' -f2)</h1>"
            elif [[ -n "$ligneTraiter" ]] && [ "$repereBalise" = "PARAGRAPHES" ]
            then
                ligneTraiter="<p>$(echo "$ligneTraiter" | cut -d'=' -f2)</p>"
            fi
        else
            if [ $countLi -eq 1 ];
            then
                ligneTraiter="<h1>$(echo "$ligneTraiter")</h1>"
            elif [[ -n "$ligneTraiter" ]]
            then
                ligneTraiter="<p>$(echo "$ligneTraiter")</p>"
            fi
        fi

        echo "$ligneTraiter" >> fileConverted/"$nomFicTraiter"
    done
done 