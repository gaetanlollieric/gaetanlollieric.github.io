#!/bin/bash

tail -n +4 "Tableau des médailles v2.csv" | #commence a la ligne 3
sort -s -t ',' -k1 -k2 -k3 -k4 -nr | #trie par nombre de médaille obtenue et ordre alphabétique
awk -F',' '{print $0","($2+$3+$4)}' | #calcul le nombre de médaille total par pays et créé une nouvelle colonne pour stocker le nombre de médaille
awk -F',' ' 
BEGIN { OFS="," }
{ 
    if ($2 == prev_or && $3 == prev_argent && $4 == prev_chocolat) { 
        carac = "-"
    } else {
    	rang++
        carac = rang
        prev_or = $2
        prev_argent = $3
        prev_chocolat = $4
    }
    print carac, $0
}' > Tableau_medaille_etape_3.csv #chocolat est la médaille de bronze

