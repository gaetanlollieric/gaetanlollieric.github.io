#!/usr/bin/bash

#Korentin 100%
chmod +x convertionAuto.bash
./conversionAuto.bash

#Enzo 45%
#Ji-o 45%
#Korentin 10%
chmod +x flagAuto.bash
./flagAuto.bash

#Enzo 30%
#Ji-o 30%
#Gaetan 20%
#korentin 20%
chmod +x miseEnPageTxt.bash
./miseEnPageTxt.bash

#Gaetan 100%
chmod +x scriptTableauEtape3.bash
./scriptTableauEtape3.bash
