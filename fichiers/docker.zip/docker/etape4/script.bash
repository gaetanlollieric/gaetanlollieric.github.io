#!/bin/bash


#95% Gaëtan
#5% Korentin

#la convertion doker html2pdf est tout en bas

#pour gérer correctement les espaces dans les noms de fichier trouvé sur internet
SAVEIFS=$IFS
IFS=$'\n'

#traitement de tous les fichiers CSV
for file in *.csv; 
do
    # Vérifier si le fichier existe
    if [ ! -f "$file" ];
    then
        echo "Aucun fichier CSV trouvé"
        exit 1
    fi
    
    #creer un fichier temporaire
    fichier_temp="fichier_temp.txt"
    
    #creer un fichier temporaire2
    fichier_temp2="fichier_temp2.txt"
    
    # Créer un fichier de sortie
    sortie_fic="${file%.*}_converti.html"
    
    tail -n +4 "$file" | #commence a la ligne 3
    sort -s -t ',' -k1 -k2 -k3 -k4 -nr | #trie par nombre de médaille obtenue et ordre alphabétique
    awk -F',' '{print $0","($2+$3+$4)}' | #calcul le nombre de médaille total par pays
    awk -F',' ' 
    BEGIN { OFS="," }
    { 
        if ($2 == prev_or && $3 == prev_argent && $4 == prev_chocolat) { 
            carac = "-"
        } else {
            rang++
            carac = rang
            prev_or = $2
            prev_argent = $3
            prev_chocolat = $4
        }
        print carac, $0
    }' > "$fichier_temp"
    
    #calcul du total des médailles
    total_medailles=$(awk -F',' '{somme+=$6} END {print somme}' "$fichier_temp")

    #ajout de la colonne de pourcentage en utilisant awk avec LC_NUMERIC=C pour forcer le point décimal trouvé sur internet 
    LC_NUMERIC=C awk -F',' -v total="$total_medailles" '{printf "%s,%.4f\n", $0, ($6/total)*100}' "$fichier_temp" > "$fichier_temp2"
    
    
    echo '<!DOCTYPE html>
    <html lang="fr">
	<head>
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <title>Tableau medailles</title>
	    <style>
		table, th, td {
		  border: 1px solid black;
		  border-collapse: collapse;
		  font-size: 5px;
		}
      </style>
	</head>
	<body>
		<h1>Tableau des médailles des JO</h1>
		<table>
			<thead>
				<tr>
					<th>Rang</th>
					<th>Pays</th>
					<th>Or</th>
					<th>Argent</th>
					<th>Bronze</th>
					<th>Total</th>
					<th>Pourcentage</th>
				</tr>
			</thead>
			<tbody>' > "$sortie_fic"
	    
    
    #création d'un bloc de commande pour rediriger toute le block de commande vers le fichier temp2 
    {
        
        #pour chaque ligne du fichier ajouter tr
        while IFS= read -r ligne; do
            echo -n "<tr>"
            
            #pour chaque champ de la ligne td
            echo "$ligne" | tr ',' '\n' | while IFS= read -r champs; do
                echo -n "<td>$champs</td>"
            done
            echo "</tr>"
        done < "$fichier_temp2"
        echo "</tbody>"
        echo "</table>"
    } >> "$sortie_fic"
    
    echo "<img src='logoJO.png' title='logo' alt='logo'>
    </body>
</html>" >> "$sortie_fic"
    
    #supprime les fichier temp
    rm "$fichier_temp"
    rm "$fichier_temp2"
    
    
    
    
    
    
    #lance le conteneur Docker en arrière-plan 
    docker run -dit --name "dockhtml2pdf" --rm bigpapoo/sae103-html2pdf

    #copie le fichier HTML du répertoire local vers le conteneur Docker
    docker cp "./$sortie_fic" dockhtml2pdf:/data/

    #execute la commande weasyprint dans le conteneur pour convertir le fichier HTML en PDF
    docker exec dockhtml2pdf weasyprint "/data/${sortie_fic}" "/data/output.pdf"

    #copie le fichier PDF généré du conteneur vers le répertoire local
    docker cp dockhtml2pdf:/data/output.pdf ./pdfPageWeb.pdf

    #arrete et supprime le conteneur
    docker stop dockhtml2pdf
    
    #rm "$sortie_fic"
    echo "Traitement terminé pour '$file' -> '$sortie_fic'"
done



#restaurer IFS
IFS=$SAVEIFS
