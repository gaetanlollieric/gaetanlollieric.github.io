import pygame

class TirePlayer :
    def __init__(self, image, center) :
        """ Initialisation d'un objet de classe Balle a partir de deux arguments :
    - image est l'adresse relative ou absolue de l'image voulue pour l'objet ;
    - center est un tuple de deux entiers donnant la position du centre de la balle lors de
    sa création."""

        self.image = pygame.image.load(image).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.vitesseT = 8
    
    def affiche(self, fenetre) :#affiche les ennemis
        fenetre.blit(self.image, self.rect)
        
    def deplaceTJ(self) :#creer un missile qui monte
        self.rect = self.rect.move(0,-self.vitesseT)
    
    def collision(self, targetRect) :#renvoie si ya une collison
        return self.rect.colliderect(targetRect)
    

    
