import pygame
import button
from main import *
#create display window
screenHeight= 540
ScreenWidht = 960

screen = pygame.display.set_mode((ScreenWidht, screenHeight))
pygame.display.set_caption('SPACE INVADERS')

#load button images
start_img = pygame.image.load('imageSound/start_btn.png').convert_alpha()
exit_img = pygame.image.load('imageSound/exit_btn.png').convert_alpha()

#create button instances
start_button = button.Button(340, screenHeight//2+10, start_img, 0.8)
exit_button = button.Button(590, screenHeight//2+10, exit_img, 0.8)

#game loop
run = True
while run:

	screen.fill((37, 45, 152))

	if start_button.draw(screen):
		game()
	if exit_button.draw(screen):
		pygame.quit()

	#event handler
	for event in pygame.event.get():
		#quit game
		if event.type == pygame.QUIT:
			run = False

	pygame.display.update()

pygame.quit()