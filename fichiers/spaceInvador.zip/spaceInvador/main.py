import pygame
from pygame.locals import *
from TireJoueur import TirePlayer
from VaisseauxEnnemi import Ennemi
from random import randint
from fonction import *
       
def game():
    pygame.init()
    pygame.key.set_repeat(400, 30)

    fenetre = pygame.display.set_mode((960, 540))
    fond = pygame.image.load("imageSound/background.jpg").convert()
    perso = pygame.image.load("imageSound/Perso.png").convert_alpha()
    persoRect = perso.get_rect()
    persoRect.topleft=(960/2-40,460)
    ennemi=pygame.image.load('imageSound/Ennemi.png').convert_alpha()
    ennemiRect= ennemi.get_rect()
    
    fenetre.blit(fond,(0,0))
    vieAffiche=pygame.image.load("imageSound/3vie.png")

    listeTE=[]
    listeTJ=[]
    listeE=[]
    score=0 
    nombreVie=3
    speed = 400
    vague = 0
    #pygame.mixer.Channel(0).play(pygame.mixer.Sound('imageSound/fond.wav'))
    
    while nombreVie>0:

        fenetre.blit(fond,(0,0))
        
        nbTEnnemi(listeTE,listeE) 
           
        keys = pygame.key.get_pressed()
        if keys[K_LEFT] and persoRect.left>=0: #condition qui regarde si la touche ← est appuyée
            persoRect.x -= speed * 0.01 #deplace le joueur a gauche a la vitesse de la variable speed qui varie et que le joueur n'est pas en dehors de la limite
        if keys[K_RIGHT] and persoRect.right<=960: #condition qui regarde si la touche → est appuyée
            persoRect.x += speed * 0.01 #deplace le joueur a gauche a la vitesse de la variable speed qui varie et que le joueur n'est pas en dehors de la limite
            
        if keys[K_SPACE] and not espaceAppuye and len(listeTJ)<8: #condition qui regarde si la touche [ ] est appuyée et et si la longueur  de la liste des tire du joueur est <8
            listeTJ.append(TirePlayer('imageSound/TireP.png', persoRect.center)) #ajoute l'image a une liste 
            espaceAppuye = True
            soundTire() #apelle la fonction sound pour mettre le son si la contion est vraie
        elif not keys[K_SPACE]: 
            espaceAppuye = False 

        if len(listeE)==0:
            listeE,vague = nbEnnemi(listeE,vague)
        
        for e in listeE:
            e.deplaceV()
            e.affiche(fenetre)
            
        deplacementAffichageTJ(listeTJ,fenetre)
        score,listeTE,listeJ,listeE=collisionTJoueur(score,listeTE,listeTJ,fenetre,listeE)
        nombreVie,perso,vieAffiche,speed = collisionJoueur(listeTE,persoRect,fenetre,nombreVie,perso,vieAffiche,speed)

        fenetre.blit(vieAffiche,(20,20)) #affiche les vies
        fenetre.blit(perso, persoRect) #affiche le perso
        affichageScore(score,fenetre)# Affichage du score
        affichageVague(vague,fenetre)#affiche les vagues
        
        pygame.display.update()
        pygame.time.wait(5)
        event()
    pygame.mixer.Channel(1).play(pygame.mixer.Sound('imageSound/hurt.MP3'))
    event()
    
if __name__ == "__main__":
    game()  