import pygame
from random import randint

class Ennemi :
    def __init__(self, image, center):
        """ Initialisation d'un objet de classe Balle a partir de deux arguments :
    - image est l'adresse relative ou absolue de l'image voulue pour l'objet ;
    - center est un tuple de deux entiers donnant la position du centre de la balle lors de
    sa création."""

        self.image = pygame.image.load(image).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.vitesse = 3
        self.direction = 1
        self.vie = 3
        
    def affiche(self, fenetre):#affiche les ennemis
        fenetre.blit(self.image, self.rect)

    def deplaceTE(self):#creer un missile qui descend 
        self.rect = self.rect.move(0,self.vitesse)
        
    def collision(self, targetRect):#renvoie si ya une collison
        return self.rect.colliderect(targetRect)

    def deplaceV(self):#fait deplacer les ennemis aleatoirements
        self.rect = self.rect.move(randint(1,3)*self.direction, 0)
        if self.rect.left<=5 or self.rect.right >= 950 or self.rect.left<=0 or self.rect.right >= 950:
            self.direction*=-1
        elif randint(1,200)<=2: 
            self.direction*=-1

    
    def tireRecu(self):#enleve une vie quand on est toucher par un missile ennemis
        self.vie -=1
