import pygame
from pygame import * 
from pygame.locals import *
from TireJoueur import TirePlayer
from VaisseauxEnnemi import Ennemi
from random import randint

def nbTEnnemi(listeTE,listeE):
    """cette fonction prend en argument la liste des tires ennemis et la liste des ennemis pour ajouter le tire
    a l'ennemi passé dans la boucle. Elle a une condition qui empeche d'avoir plus de 30 tires pour tous les
    vaisseaux"""
    for e in listeE :
        if len(listeTE)<15 and randint(1,500)<=35:
            listeTE.append(Ennemi('imageSound/Tire.png',e.rect.center))

def nbEnnemi(listeE,vague):
    """cette fonction s'occupe du nombre de vaisseaux en fonction de la vague.
    Elle ajoute un vaisseaux par vague."""
    vague+=1
    while len(listeE)!=vague: #boucle tant que qui regarde si la longueure de la liste des ennemis est < a la variable vague
        listeE.append(Ennemi('imageSound/Ennemi.png',(randint(50,900),50))) #ajoute l'image a listeE
    return listeE,vague

def affichageScore(score,fenetre):
    """cette fonction affiche le score du joueur, elle doit prendre en argument le score et la fenetre."""
    font = pygame.font.Font(None, 36)#initialisation du style d'ecriture
    scoreTxt = font.render("Score : "+str(score),True,(255,255,255)) #initialisation du texte d'ecriture (couleur,
    scoreRect = scoreTxt.get_rect() #créé un rectangle autour du texte
    scoreRect.topleft = (20, 75) #placement du texte
    fenetre.blit(scoreTxt, scoreRect)

def affichageVague(vague,fenetre):
    """cette fonction affiche la vague actuel. Elle prend en argument la vague, ainsi que la fenetre"""
    font = pygame.font.Font(None, 36) #initialisation du style d'ecriture
    vagueTxt = font.render("Vague : "+str(vague),True,(255,255,255)) #initialisation du style d'ecriture
    vagueRect = vagueTxt.get_rect() #créé un rectangle autour du texte
    vagueRect.topleft = (20, 100) #placement du texte
    fenetre.blit(vagueTxt, vagueRect)



def collisionTJoueur(score,listeTE,listeTJ,fenetre,listeE):
    """cette fonction gère toutes les collisions, elle retire les elements qui entre en collision
    avec le tire du joueur, ainsi que le tire du joueur.
    Elle prend en argument le score, la liste des tires ennemis et joueur, ainsi que la fenetre, et la liste des ennemis.
    Elle affiche aussi les tire du joueur"""
    for tJ in listeTJ: #parcour par élément de listeTJ
        if tJ.rect.top <= -30: #regarde si le tire est en dehors de la fenetre
            listeTJ.remove(tJ) #retire l'élément t de la liste
        else:
            exist = True
            for tE in listeTE: 
                if tJ.collision(tE.rect):  # Utilise la méthode collision de TirePlayer
                    listeTE.remove(tE)
                    listeTJ.remove(tJ)
                    score += 1
                    exist = False
                    break #casse la boucle pour empecher la collision avec un autre élément
            if exist :            
                for ennemi in listeE:
                    if tJ.collision(ennemi.rect):
                        ennemi.tireRecu()
                        if ennemi.vie<=0:
                            listeE.remove(ennemi)
                        listeTJ.remove(tJ)
                        score += 5
                        break #casse la boucle pour empecher la collision avec un autre élément
    return score, listeTE, listeTJ, listeE # renvoie les variables suivantes score, listeTE, listeTJ, listeE

def deplacementAffichageTJ(listeTJ,fenetre):
    """cette fonction deplace les tires du joueur. Elle passe en arguments listeTJ et fenetre"""
    for tJ in listeTJ: #parcour par élément de la liste listeJ
        tJ.deplaceTJ() #utilise la méthode deplaceTJ de la class TirePlayer
        tJ.affiche(fenetre)

def AffichageTE(listeTE,fenetre):
    """cette fonction deplace les tires ennemis. Elle passe en arguments listeTJ et fenetre"""
    for tE in listeTE:
        tE.affiche(fenetre)

def collisionJoueur(listeE,persoR,fenetre,nbV,perso,vieAffiche,speed):
    """cette fonction deplace le tire ennemi, enlève le tire ennemi s'il est en dehors de la fenêtre,
    regarde si les tires ennemis ont été en collision.
    Cette fonction appelle aussi les fonction nbVie et AffichageTE."""
    for tE in listeE : #te correspond au tire Ennemi
        tE.deplaceTE()
        if tE.rect.top >= 550: # regarde si le tire est en dehors de la fenetre
            listeE.remove(tE) # retire le tire
        else :
            colTireEnnemi = tE.rect.collidelist(listeE)
            if tE.collision(persoR): #condition qui regarde si le tire a été en colision avec le joueur
                listeE.pop(colTireEnnemi) #retire le tire
                nbV,perso,vieAffiche,speed = nbVieRestante(nbV,perso,vieAffiche,fenetre,speed)
        AffichageTE(listeE,fenetre)
    return nbV,perso,vieAffiche,speed
        
def nbVieRestante(nbV,perso,vieAffiche,fenetre,speed):
    """cette fonction affiche et renvoie le nombre de vie ainsi que l'image correspondante
    au nombre de vie, et l'image du vaisseau correspondant a son nombre de vie. Elle definit aussi
    la vitesse de déplacement"""
    nbV-=1
    if nbV==2:
        #pygame.mixer.Channel(1).play(pygame.mixer.Sound('imageSound/hurt.MP3'))
        perso = pygame.image.load("imageSound/Perso2Vie.png").convert_alpha()
        vieAffiche=pygame.image.load("imageSound/2vie.png").convert_alpha()
        speed-=100
    elif nbV==1:
        #pygame.mixer.Channel(1).play(pygame.mixer.Sound('imageSound/hurt.MP3'))
        perso = pygame.image.load("imageSound/Perso1Vie.png").convert_alpha()
        vieAffiche=pygame.image.load("imageSound/1vie.png").convert_alpha()
        speed-=100
    fenetre.blit(vieAffiche,(20,20))
    return nbV,perso,vieAffiche,speed

def soundTire():
    mixer.init()
    mixer.music.load("imageSound/song.mp3")
    mixer.music.set_volume(10)
    mixer.music.play()

def event():
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

