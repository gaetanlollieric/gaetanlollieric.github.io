from flask import Flask, render_template, request
import sqlite3
import time

app = Flask(__name__)
indice_dep = 0

##ROUTES##
@app.route('/',methods = ['GET','POST']) #initialisation de la route
def homePage(i=0):
    if request.method == 'POST':#condition qui regarde si la methode est "post"
        i = int(request.form['iActuel'])
    themes,annees,nbPieces = initialisationSelect()
    return render_template('homePage.html',resultatHomePage=initialisationSetHome()[i:i+100],i=i,themes=themes,annees=annees,nbPieces=nbPieces)

@app.route('/resultatUnique/', methods=['POST'])
def resultatUnique():
    if request.form['ajouter'] == 'True':
        numSet = request.form['numSet']
        nom = request.form['nom']
        annee = request.form['annee']
        nbPiece = request.form['nbPiece']
        image = request.form['image']
        theme = request.form['theme']
        favoris = request.form['favoris']
        fonctionAjouterSet(numSet, nom, annee, nbPiece, image, theme, favoris)
    return render_template('resultatUnique.html', resultat=rechercheUnique(request.form['numSet']))

@app.route('/resultatsMultiples/',methods = ['POST'])
def resultatsMultiples():
    return render_template('resultatsMultiples.html',resultats=rechercheFiltre()) 

@app.route('/resultatModifie/', methods =['POST'])
def resultatModifie():
    changement(table='Lego',column=request.form['column'],newValue=request.form['newValue'],idValue=request.form['id']) #icicicic
    return render_template('resultatModifie.html',resultatModifie=rechercheUnique(request.form['numSetModifie']))

@app.route('/favoris/', methods =['POST'])
def favoris():
    if request.form['validerRetirerFavoris']=='True':
        ajoutFavoris(request.form['numSetFav'])
    elif request.form['validerRetirerFavoris']=='False':
        retirerFavoris(request.form['numSetFav'])
    else:
        None
    return render_template('favoris.html',favoris=rechercheFavoris())

@app.route('/ajoutSet/', methods =['POST'])
def ajoutSet():
    return render_template('ajoutSet.html')


##FONCTION A COTE##
def reqBuild():
    req ="SELECT set_name,set_number,image_url FROM Lego WHERE "
    nbReq=0
    if request.form['annee']!='aucun':
        nbReq=+1
        req+=f"year_released = '{request.form['annee']}' "
    if request.form['theme']!='aucun':
        if nbReq==1:
            req+= 'AND '
        nbReq=+1
        req+=f"theme_name = '{request.form['theme']}' "
    if request.form['nbPiece']!='aucun':
        if nbReq>0:
            req+= 'AND '
        req+=f"number_of_parts = '{request.form['nbPiece']}' "
    req+=';'
    return req

def rechercheFiltre():
    """cette fonction renvoie les resultats de la recherche avec les arguments donnés"""
    req = reqBuild()
    connexion=sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute(f"""{req}""")
    resultats_recherche =curseur.fetchall()
    connexion.close()
    return resultats_recherche

def rechercheUnique(element):
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute("""SELECT set_name,set_number,theme_name,year_released,number_of_parts,image_url,id,favoris
                       FROM Lego
                       WHERE set_number = ?;""", [element]) 
    resultat = curseur.fetchall()
    connexion.close()
    return resultat

def rechercheFavoris():
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute("""SELECT set_name,set_number,image_url
                       FROM Lego
                       WHERE favoris = 'True';""") 
    favoris = curseur.fetchall()
    connexion.close()
    return favoris

def initialisationSetHome():
    connexion=sqlite3.connect("lego.db")                                #connexion a la base de donnée lego.db
    curseur = connexion.cursor()
    curseur.execute("""SELECT set_name,set_number,image_url
                       FROM Lego;""")                                   #execution de la recherche
    resultatsHomePage=curseur.fetchall()                                #on stoque les resultats dans la variable resultats_recherche
    connexion.close()                                                   #on ferme la connexion de la DB pour eviter les surcharges
    return resultatsHomePage                                            #on renvoi la variable resultats_recherche

def initialisationSelect():
    connexion=sqlite3.connect("lego.db")                                #connexion a la base de donnée lego.db
    curseur = connexion.cursor()
    curseur.execute("""SELECT DISTINCT theme_name
                       FROM Lego
                       ORDER BY theme_name ASC;""")                     #execution de la recherche
    theme=curseur.fetchall()                                            #on stoque les resultats dans la variable theme
    curseur.execute("""SELECT DISTINCT year_released
                       FROM Lego
                       ORDER BY year_released ASC;""")                  #execution de la recherche
    annee=curseur.fetchall()                                            #on stoque les resultats dans la variable annee
    curseur.execute("""SELECT DISTINCT number_of_parts
                       FROM Lego
                       ORDER BY number_of_parts ASC;""")                #execution de la recherche
    nbPiece=curseur.fetchall()                                          #on stoque les resultats dans la variable nbPiece
    connexion.close()
    return theme,annee,nbPiece
    
def changement(table, column, newValue, idValue):
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
#     try :
    curseur.execute(f"UPDATE {table} SET {column} = ? WHERE id = ?;", (newValue, idValue))
#     except :
#         print(f"UPDATE {table} SET {column} = '{newValue}' WHERE id = '{idValue}';")
#         raise ValueError
    if curseur.rowcount > 0: #Validation de la modification
        print('Le changement a été effectué')
        connexion.commit()
    else:
        print('Aucune correspondance trouvée, la mise à jour a échoué')
    connexion.close()

def ajoutFavoris(numSetValue):
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute(f"UPDATE Lego SET favoris = 'True' WHERE set_number LIKE ?;", [numSetValue])
    connexion.commit()
    connexion.close()

def retirerFavoris(numSetValue):
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute(f"UPDATE Lego SET favoris = 'False' WHERE set_number = ?;", [numSetValue])
    connexion.commit()
    connexion.close()

def fonctionAjouterSet(num,nom,annee,nbP,img,theme,fav):
    connexion = sqlite3.connect("lego.db")
    curseur = connexion.cursor()
    curseur.execute('SELECT MAX(id) FROM LEGO')
    id = curseur.fetchone()
    for carac in id:
        newId=int(carac)
    newId+=1
    curseur.execute(f"INSERT INTO Lego VALUES(?,?,?,?,?,?,?,?)",[newId,num,nom,annee,nbP,img,theme,fav])
    connexion.commit()
    connexion.close()

if __name__=="__main__":
    app.run(port=5012)