let confirmerSet = document.getElementById('confirmerSet');
confirmerSet.addEventListener('click', alertS);

function alertS(event) {
    event.preventDefault(); // Empêche le bouton de soumetre le formulaire
    const numSet = document.getElementById('numSet').value;
    if (numSet === '') {
        alert("Veuillez remplir les champs");
        return;
    }
	if (numSet.includes('-')) {
		this.closest('form').submit();
    } else {
        alert("Le numéro du set ne contient pas de '-'");
		return;
    }
	// Si les conditions sont remplies, le formulaire peut etre envoyé 
    this.closest('form').submit();
}
