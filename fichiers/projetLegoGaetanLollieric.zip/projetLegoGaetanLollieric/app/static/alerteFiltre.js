let confirmerFiltre = document.getElementById('confirmerFiltre');
confirmerFiltre.addEventListener('click', alerteF);

function alerteF(event) {
    event.preventDefault(); // Empêche le bouton de soumetre le formulaire
    const theme = document.getElementById('theme').value;
    const annee = document.getElementById('annee').value;
    const nbPiece = document.getElementById('nbPiece').value;
    if (theme === 'aucun' && annee === 'aucun' && nbPiece === 'aucun') {
        alert("Veuillez remplir les champs");
        return;
    }
    // Si les conditions sont remplies, le formulaire peut etre envoyé 
    this.closest('form').submit();
}