let confirmerSet = document.getElementById('confirmerSet');
confirmerSet.addEventListener('click', alertS);

function alertS(event) {
    event.preventDefault();  // Empêche le bouton de soumetre le formulaire
    const numSet = document.getElementById('numSet').value;
    if (numSet === '') {
        alert("Votre recherche doit s'écrire sous la forme '0000-1'. Ex: 42100-1");
        return;
    }
    // Si les conditions sont remplies, le formulaire peut etre envoyé 
    this.closest('form').submit();
}

let confirmerFiltre = document.getElementById('confirmerFiltre');
confirmerFiltre.addEventListener('click', alerteF);

function alerteF(event) {
    event.preventDefault(); // Empêche le bouton de soumetre le formulaire
    const theme = document.getElementById('theme').value;
    const annee = document.getElementById('annee').value;
    const nbPiece = document.getElementById('nbPiece').value;
    if (theme === 'aucun' && annee === 'aucun' && nbPiece === 'aucun') {
        alert("Veuillez remplir les champs");
        return;
    }
    // Si les conditions sont remplies, le formulaire peut etre envoyé 
    this.closest('form').submit();
}